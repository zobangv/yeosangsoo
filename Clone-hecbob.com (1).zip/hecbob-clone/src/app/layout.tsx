import type { Metadata } from 'next';
import ClientBody from './ClientBody';
import './globals.css';

export const metadata: Metadata = {
  title: '핵밥 - 대한민국 No.1 덮밥 & 라멘 프랜차이즈',
  description: '핵밥은 대한민국 No.1 덮밥 & 라멘 프랜차이즈입니다. 월매출 1억 돌파, 100호점 한정 프로모션, 성공적인 창업 스토리를 확인하세요.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body>
        <ClientBody>{children}</ClientBody>
      </body>
    </html>
  );
}
